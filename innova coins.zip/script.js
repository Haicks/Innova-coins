/* ---------- Dados base (extraídos da lista de turmas e da tabela de moedas) ---------- */

const TURMAS = [
  {
    id: "terca-discovery-14h",
    dia: "Terça-feira",
    nome: "Discovery 14h",
    horario: "14h",
    professores: ["Matheus"],
    alunos: [
      "Bernardo Sousa Martins",
      "Bianca da Silva Farias",
      "Carlos Roberto do Nascimento",
      "Danilo Levi Carvalho Alves e Silva",
      "Davi Gomes Passos",
      "Guilherme de Lima Lyra",
      "Heitor de Siqueira Mattioli",
      "Luis Augusto Moura Silva",
      "Nicolas Barros de França",
      "Sophia Moura da Silva"
    ]
  },
  {
    id: "quarta-curiosity4-14h",
    dia: "Quarta-feira",
    nome: "Curiosity 4",
    horario: "14h",
    professores: ["Matheus"],
    alunos: [
      "Aurora Naves Felix",
      "Davi Augusto Rocha de Holanda",
      "Hugo Naves Felix",
      "Calebe Sales Luz"
    ]
  },
  {
    id: "sexta-discovery2-9h",
    dia: "Sexta-feira",
    nome: "Discovery 2",
    horario: "9h",
    professores: ["Jhenifer", "Matheus"],
    alunos: [
      "Arthur Tozetti",
      "Davi Rodrigues de Souza",
      "Gabriel Souza Salgado",
      "George Gabriel da Cunha",
      "Josué Abreu Pereira",
      "Kalel Pinheiro Lemes de Oliveira",
      "Luciano Macêdo de Carvalho",
      "Mariana Nunes dos Santo",
      "Miguel Monteiro Barbosa de Souza",
      "Rafael Durães de Faria",
      "Samuel Araújo dos Passos",
      "Túlio dos Santos Nobre"
    ]
  },
  {
    id: "sexta-discovery4-14h",
    dia: "Sexta-feira",
    nome: "Discovery 4",
    horario: "14h",
    professores: ["Matheus", "Jhenifer"],
    alunos: [
      "Cecília Azevedo Silva de Carvalho",
      "Luigi Viana de Almeida",
      "Letícia Ozeias Medeiros",
      "Ryan Martins Braz"
    ]
  },
  {
    id: "sabado-curiosity4-08h",
    dia: "Sábado",
    nome: "Curiosity 4",
    horario: "8h",
    professores: ["Matheus"],
    alunos: [
      "Bento Moreira Prates Menezes",
      "Bento Guidugli Debuz Vieira",
      "Caique Curvello Marinho",
      "Calebe Sales Luz",
      "Eliza Barros Rodrigues",
      "Gabriel Garcia dos Santos",
      "Maria Clara Pereira Ferreira Benvindo",
      "Miguel Leão Gomes",
      "Miguel Alves Costa",
      "Sofia Albuquerque Aerre"
    ]
  },
  {
    id: "sabado-discovery2-10h",
    dia: "Sábado",
    nome: "Discovery 2",
    horario: "10h",
    professores: ["Matheus"],
    alunos: [
      "Heitor Reis Lima",
      "Heitor Souza de Jesus",
      "João Pedro Santana",
      "João Vieira dos Santos Neto",
      "Jonas Souza de Jesus",
      "Miguel Nascimento",
      "Pedro Lucas Monteiro de Sousa",
      "Pedro Tavares Silva Barroso"
    ]
  },
  {
    id: "sabado-discovery-13h",
    dia: "Sábado",
    nome: "Discovery",
    horario: "13h",
    professores: ["Matheus"],
    alunos: [
      "Gabriel Merten Pereira",
      "Theo Richard Almeida Jordão"
    ]
  }
];

const BENEFICIOS = [
  { id: "b1", label: "Participação ativa nas aulas", pontos: 5 },
  { id: "b2", label: "Cumprimento de prazos de entrega de atividades", pontos: 10 },
  { id: "b3", label: "Colaboração nas atividades em grupo", pontos: 10 },
  { id: "b4", label: "Respeito aos colegas, professores e equipe escolar", pontos: 5 },
  { id: "b5", label: "Organização e cuidado com os materiais escolares", pontos: 5 },
  { id: "b6", label: "Apoio e mentoria a colegas em dificuldades", pontos: 10 },
  { id: "b7", label: "Capacidade de autoaprendizagem", pontos: 5 },
  { id: "b8", label: "Proatividade", pontos: 5 },
  { id: "b9", label: "Entrega de atividades com qualidade", pontos: 5 },
  { id: "b10", label: "Criatividade e inovação na resolução de problemas", pontos: 10 },
  { id: "b11", label: "Desenvolvimento de soft skills", pontos: 5 }
];

const PENALIDADES = [
  { id: "p1", label: "Falta de respeito aos colegas e professores", pontos: -10 },
  { id: "p2", label: "Atrasos na chegada às aulas", pontos: -5 },
  { id: "p3", label: "Não participar de atividades em grupo", pontos: -10 },
  { id: "p4", label: "Falta de participação ativa nas aulas", pontos: -5 },
  { id: "p5", label: "Desorganização e descuido com os materiais escolares", pontos: -5 },
  { id: "p6", label: "Desrespeito às regras e políticas da escola", pontos: -10 },
  { id: "p7", label: "Uso inadequado de dispositivos eletrônicos durante a aula", pontos: -5 },
  { id: "p8", label: "Interrupções frequentes durante as explicações", pontos: -5 },
  { id: "p9", label: "Conversas paralelas durante a aula", pontos: -5 },
  { id: "p10", label: "Uso inadequado de linguagem", pontos: -5 },
  { id: "p11", label: "Não entrega das atividades/desafios", pontos: -5 }
];

const STORAGE_KEY = "innovaCoinsState_v1";

const AVATAR_COLORS = ["#FF5C8A", "#4FD1FF", "#33E1B0", "#FFC93C", "#B98CFF", "#FF9F5A"];

const COIN_ICON = `<svg class="coin-icon" viewBox="0 0 24 24" aria-hidden="true">
  <circle cx="12" cy="12" r="10" fill="#FFC93C"/>
  <circle cx="12" cy="12" r="10" fill="none" stroke="#E0A81C" stroke-width="1.6"/>
  <circle cx="12" cy="12" r="6.4" fill="none" stroke="#170B33" stroke-width="1" stroke-dasharray="1.2 1.8" opacity="0.4"/>
</svg>`;

function initials(nome) {
  const parts = nome.trim().split(/\s+/);
  const first = parts.length > 0 && parts[0].length > 0 ? parts[0][0] : "";
  const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
  return (first + last).toUpperCase();
}

function avatarColor(nome) {
  let hash = 0;
  for (let i = 0; i < nome.length; i++) hash = nome.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function levelBadge(total) {
  if (total < 0) return { label: "Atenção", cls: "badge-atencao" };
  if (total < 25) return { label: "Bronze", cls: "badge-bronze" };
  if (total < 60) return { label: "Prata", cls: "badge-prata" };
  if (total < 100) return { label: "Ouro", cls: "badge-ouro" };
  return { label: "Diamante", cls: "badge-diamante" };
}

/* ---------- Estado ---------- */

let state = loadState();
let currentTurmaId = "overview";
let activeStudentKey = null;
let currentView = "pontos"; // "pontos" | "chamada"
let currentChamadaDate = todayISO();

function todayISO() {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function formatDateBR(iso) {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function studentKey(turmaId, nome) {
  return turmaId + "::" + nome;
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      parsed.students = parsed.students || {};
      parsed.attendance = parsed.attendance || {};
      return parsed;
    }
  } catch (e) {
    console.warn("Não foi possível ler dados salvos:", e);
  }
  return { students: {}, attendance: {} };
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Não foi possível salvar dados:", e);
  }
}

function getStudentEntry(turmaId, nome) {
  const key = studentKey(turmaId, nome);
  if (!state.students[key]) {
    state.students[key] = { log: [] };
  }
  return state.students[key];
}

function getStudentTotal(turmaId, nome) {
  const entry = getStudentEntry(turmaId, nome);
  return entry.log.reduce((sum, item) => sum + item.pontos, 0);
}

function getTurmaAverage(turma) {
  if (turma.alunos.length === 0) return 0;
  const total = turma.alunos.reduce((sum, nome) => sum + getStudentTotal(turma.id, nome), 0);
  return total / turma.alunos.length;
}

function getTurmaHighlight(turma) {
  let best = null;
  let bestTotal = -Infinity;
  turma.alunos.forEach((nome) => {
    const total = getStudentTotal(turma.id, nome);
    if (total > bestTotal) {
      bestTotal = total;
      best = nome;
    }
  });
  return { nome: best, total: bestTotal };
}

function findTurma(id) {
  return TURMAS.find((t) => t.id === id);
}

/* ---------- Dados: chamada ---------- */

function ensureAttendanceRecord(turmaId, date) {
  state.attendance[turmaId] = state.attendance[turmaId] || {};
  state.attendance[turmaId][date] = state.attendance[turmaId][date] || { descricao: "", presencas: {} };
  return state.attendance[turmaId][date];
}

function getAttendanceRecord(turmaId, date) {
  const turmaRecords = state.attendance[turmaId];
  if (!turmaRecords) return null;
  return turmaRecords[date] || null;
}

function isPresente(turmaId, date, nome) {
  const rec = getAttendanceRecord(turmaId, date);
  if (!rec || !(nome in rec.presencas)) return true;
  return rec.presencas[nome];
}

function togglePresenca(turmaId, date, nome) {
  const rec = ensureAttendanceRecord(turmaId, date);
  const atual = nome in rec.presencas ? rec.presencas[nome] : true;
  rec.presencas[nome] = !atual;
  saveState();
}

function updateDescricaoDia(turmaId, date, texto) {
  const rec = ensureAttendanceRecord(turmaId, date);
  rec.descricao = texto;
  saveState();
}

function listAttendanceDates(turmaId) {
  const obj = state.attendance[turmaId] || {};
  return Object.keys(obj).sort((a, b) => b.localeCompare(a));
}

function countPresentes(turma, date) {
  return turma.alunos.reduce((sum, nome) => sum + (isPresente(turma.id, date, nome) ? 1 : 0), 0);
}

/* ---------- Render: sidebar ---------- */

function renderSidebar() {
  const groupsEl = document.getElementById("sidebar-groups");
  groupsEl.innerHTML = "";

  const dias = [...new Set(TURMAS.map((t) => t.dia))];
  dias.forEach((dia) => {
    const label = document.createElement("p");
    label.className = "day-label";
    label.textContent = dia;
    groupsEl.appendChild(label);

    TURMAS.filter((t) => t.dia === dia).forEach((turma) => {
      const btn = document.createElement("button");
      btn.className = "nav-item" + (turma.id === currentTurmaId ? " active" : "");
      btn.dataset.turma = turma.id;
      btn.innerHTML = `
        <span class="nav-item-label">${turma.nome} · ${turma.horario}</span>
        <span class="nav-item-meta">${turma.alunos.length} alunos</span>
      `;
      btn.addEventListener("click", () => selectTurma(turma.id));
      groupsEl.appendChild(btn);
    });
  });

  document.querySelector(".nav-overview").classList.toggle("active", currentTurmaId === "overview");
}

/* ---------- Render: overview ---------- */

function renderOverview() {
  const content = document.getElementById("content");
  const cards = TURMAS.map((turma, i) => {
    const avg = getTurmaAverage(turma);
    const accent = AVATAR_COLORS[i % AVATAR_COLORS.length];
    return `
      <button class="overview-card" data-turma="${turma.id}" style="--accent-color:${accent}; --accent-glow:${accent}26;">
        <p class="overview-card-day">${turma.dia} · ${turma.horario}</p>
        <p class="overview-card-name">${turma.nome}</p>
        <div class="overview-card-avg-row">${COIN_ICON}<span class="overview-card-avg">${formatNumber(avg)}</span></div>
        <p class="overview-card-avg-label">coins em média por aluno</p>
        <p class="overview-card-count">${turma.alunos.length} alunos · ${turma.professores.join(" e ")}</p>
      </button>
    `;
  }).join("");

  content.innerHTML = `
    <h1 class="overview-title">Visão geral das turmas</h1>
    <p class="overview-sub">Média de Innova Coins calculada separadamente para cada turma.</p>
    <div class="overview-grid">${cards}</div>
  `;

  content.querySelectorAll(".overview-card").forEach((card) => {
    card.addEventListener("click", () => selectTurma(card.dataset.turma));
  });
}

/* ---------- Render: turma detail ---------- */

function renderTurma(turmaId) {
  const turma = findTurma(turmaId);
  const content = document.getElementById("content");

  content.innerHTML = `
    <div class="turma-header">
      <div>
        <h1 class="turma-name">${turma.nome} <span>· ${turma.horario}</span></h1>
        <p class="turma-meta">${turma.dia} · Professor(a): ${turma.professores.join(" e ")} · ${turma.alunos.length} alunos</p>
      </div>
    </div>

    <div class="tab-bar">
      <button class="tab-btn ${currentView === "pontos" ? "active" : ""}" id="tab-pontos-btn">Pontuação</button>
      <button class="tab-btn ${currentView === "chamada" ? "active" : ""}" id="tab-chamada-btn">Chamada</button>
    </div>

    <div id="tab-panel"></div>
  `;

  document.getElementById("tab-pontos-btn").addEventListener("click", () => { currentView = "pontos"; renderTurma(turmaId); });
  document.getElementById("tab-chamada-btn").addEventListener("click", () => { currentView = "chamada"; renderTurma(turmaId); });

  if (currentView === "pontos") {
    renderPontosTab(turma);
  } else {
    renderChamadaTab(turma);
  }
}

function renderPontosTab(turma) {
  const panel = document.getElementById("tab-panel");
  const avg = getTurmaAverage(turma);
  const highlight = getTurmaHighlight(turma);

  const rows = turma.alunos.map((nome) => {
    const total = getStudentTotal(turma.id, nome);
    const cls = total > 0 ? "pos" : total < 0 ? "neg" : "";
    const badge = levelBadge(total);
    return `
      <li class="student-row" data-row-nome="${escapeAttr(nome)}">
        <span class="avatar" style="background:${avatarColor(nome)}">${initials(nome)}</span>
        <span class="student-info">
          <span class="student-name">${nome}</span>
          <span class="badge ${badge.cls}">${badge.label}</span>
        </span>
        <span class="student-right">
          <span class="student-total ${cls}" id="total-${slug(nome)}">${COIN_ICON}${total}</span>
          <button class="btn-add" data-nome="${escapeAttr(nome)}" aria-label="Registrar coin para ${escapeAttr(nome)}">+</button>
        </span>
      </li>
    `;
  }).join("");

  panel.innerHTML = `
    <div class="tab-actions">
      <button class="btn btn-outline" id="export-btn">Exportar CSV</button>
      <button class="btn btn-outline" id="reset-turma-btn">Zerar turma</button>
    </div>

    <div class="stat-row">
      <div class="stat-card hero">
        <div class="stat-number">${COIN_ICON}${formatNumber(avg)}</div>
        <div class="stat-label">Média de coins da turma</div>
      </div>
      <div class="stat-card">
        <div class="stat-highlight-row">
          <span class="avatar" style="background:${highlight.nome ? avatarColor(highlight.nome) : '#4A3390'}">${highlight.nome ? initials(highlight.nome) : "—"}</span>
          <div>
            <div class="stat-highlight-name">${highlight.nome ?? "Sem registros"}</div>
            <div class="stat-highlight-total">${highlight.nome ? highlight.total + " coins · destaque da turma" : "Registre o primeiro coin"}</div>
          </div>
        </div>
      </div>
    </div>

    <ul class="student-list">${rows}</ul>
  `;

  panel.querySelectorAll(".btn-add").forEach((btn) => {
    btn.addEventListener("click", () => openDrawer(turma.id, btn.dataset.nome));
  });
  document.getElementById("export-btn").addEventListener("click", () => exportCSV(turma));
  document.getElementById("reset-turma-btn").addEventListener("click", () => resetTurma(turma));
}

function renderChamadaTab(turma) {
  const panel = document.getElementById("tab-panel");
  const date = currentChamadaDate;
  const record = getAttendanceRecord(turma.id, date);
  const descricao = record ? record.descricao : "";
  const presentes = countPresentes(turma, date);
  const dates = listAttendanceDates(turma.id);

  const rows = turma.alunos.map((nome) => {
    const presente = isPresente(turma.id, date, nome);
    return `
      <li class="attendance-row">
        <span class="avatar" style="background:${avatarColor(nome)}">${initials(nome)}</span>
        <span class="attendance-name">${nome}</span>
        <button class="btn-presence ${presente ? "present" : "absent"}" data-nome="${escapeAttr(nome)}">
          ${presente ? "Presente" : "Falta"}
        </button>
      </li>
    `;
  }).join("");

  const historyRows = dates.length === 0
    ? `<li class="history-empty">Nenhuma chamada registrada ainda.</li>`
    : dates.map((d) => {
        const rec = getAttendanceRecord(turma.id, d);
        const count = countPresentes(turma, d);
        return `
          <li class="history-item ${d === date ? "active" : ""}" data-date="${d}">
            <span class="history-date">${formatDateBR(d)}</span>
            <span class="history-desc">${rec.descricao ? escapeHtml(rec.descricao).slice(0, 60) : "Sem descrição"}</span>
            <span class="history-count">${count}/${turma.alunos.length}</span>
          </li>
        `;
      }).join("");

  panel.innerHTML = `
    <div class="stat-row">
      <div class="stat-card hero">
        <div class="stat-number">${presentes}<span style="font-size:1.1rem; color:#E6D6F7;">/${turma.alunos.length}</span></div>
        <div class="stat-label">Presentes em ${formatDateBR(date)}</div>
      </div>
      <div class="stat-card chamada-date-card">
        <label class="field-label" for="chamada-date">Data da chamada</label>
        <input type="date" id="chamada-date" value="${date}">
      </div>
    </div>

    <div class="chamada-desc-block">
      <label class="field-label" for="chamada-desc">Descrição do dia</label>
      <textarea id="chamada-desc" rows="2" placeholder="O que foi trabalhado nessa aula...">${escapeHtml(descricao)}</textarea>
    </div>

    <ul class="attendance-list">${rows}</ul>

    <div class="attendance-history">
      <h3 class="chip-title">Chamadas anteriores</h3>
      <ul class="history-list">${historyRows}</ul>
    </div>
  `;

  document.getElementById("chamada-date").addEventListener("change", (e) => {
    currentChamadaDate = e.target.value;
    renderChamadaTab(turma);
  });

  const descEl = document.getElementById("chamada-desc");
  descEl.addEventListener("change", () => updateDescricaoDia(turma.id, date, descEl.value));

  panel.querySelectorAll(".btn-presence").forEach((btn) => {
    btn.addEventListener("click", () => {
      togglePresenca(turma.id, date, btn.dataset.nome);
      renderChamadaTab(turma);
    });
  });

  panel.querySelectorAll(".history-item[data-date]").forEach((item) => {
    item.addEventListener("click", () => {
      currentChamadaDate = item.dataset.date;
      renderChamadaTab(turma);
    });
  });
}

function render() {
  renderSidebar();
  renderHeaderTotal();
  if (currentTurmaId === "overview") {
    renderOverview();
  } else {
    renderTurma(currentTurmaId);
  }
}

function renderHeaderTotal() {
  const total = TURMAS.reduce((sum, turma) => {
    return sum + turma.alunos.reduce((s, nome) => s + getStudentTotal(turma.id, nome), 0);
  }, 0);
  document.getElementById("header-total").innerHTML = `<strong>${total}</strong> coins distribuídos ao todo`;
}

function selectTurma(turmaId) {
  currentTurmaId = turmaId;
  currentView = "pontos";
  currentChamadaDate = todayISO();
  render();
}

/* ---------- Drawer (registrar pontos) ---------- */

function openDrawer(turmaId, nome) {
  activeStudentKey = { turmaId, nome };
  document.getElementById("drawer-name").textContent = nome;
  const drawerAvatar = document.getElementById("drawer-avatar");
  drawerAvatar.textContent = initials(nome);
  drawerAvatar.style.background = avatarColor(nome);
  document.getElementById("benefit-chips").innerHTML = BENEFICIOS.map(chipHtml("benefit")).join("");
  document.getElementById("penalty-chips").innerHTML = PENALIDADES.map(chipHtml("penalty")).join("");

  document.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      applyPoints(chip.dataset.id, chip.dataset.label, Number(chip.dataset.pontos));
    });
  });

  renderDrawerTotals();
  document.getElementById("drawer-overlay").classList.add("open");
}

function chipHtml(kind) {
  const list = kind === "benefit" ? BENEFICIOS : PENALIDADES;
  return (item) => `
    <button class="chip chip-${kind}" data-id="${item.id}" data-label="${escapeAttr(item.label)}" data-pontos="${item.pontos}">
      <span>${item.label}</span>
      <span class="chip-value">${item.pontos > 0 ? "+" : ""}${item.pontos}</span>
    </button>
  `;
}

function closeDrawer() {
  document.getElementById("drawer-overlay").classList.remove("open");
  activeStudentKey = null;
}

function applyPoints(id, label, pontos) {
  if (!activeStudentKey) return;
  const entry = getStudentEntry(activeStudentKey.turmaId, activeStudentKey.nome);
  entry.log.unshift({ id, label, pontos, ts: Date.now() });
  saveState();
  renderDrawerTotals();
  showToast(`${pontos > 0 ? "+" : ""}${pontos} coins — ${label}`);
  // Atualiza a lista/turma por trás do drawer sem fechar
  if (currentTurmaId !== "overview") {
    renderTurma(currentTurmaId);
    const totalEl = document.getElementById(`total-${slug(activeStudentKey.nome)}`);
    if (totalEl) {
      totalEl.classList.add("bump");
      totalEl.addEventListener("animationend", () => totalEl.classList.remove("bump"), { once: true });
    }
  }
  renderSidebar();
  renderHeaderTotal();
}

function undoLog(index) {
  if (!activeStudentKey) return;
  const entry = getStudentEntry(activeStudentKey.turmaId, activeStudentKey.nome);
  entry.log.splice(index, 1);
  saveState();
  renderDrawerTotals();
  if (currentTurmaId !== "overview") renderTurma(currentTurmaId);
}

function renderDrawerTotals() {
  if (!activeStudentKey) return;
  const entry = getStudentEntry(activeStudentKey.turmaId, activeStudentKey.nome);
  const total = entry.log.reduce((sum, item) => sum + item.pontos, 0);
  document.getElementById("drawer-total").textContent = total;

  const logList = document.getElementById("log-list");
  if (entry.log.length === 0) {
    logList.innerHTML = `<li class="log-empty">Nenhum registro ainda.</li>`;
    return;
  }
  logList.innerHTML = entry.log.map((item, i) => {
    const cls = item.pontos > 0 ? "pos" : "neg";
    return `
      <li class="log-item">
        <span class="log-item-delta ${cls}">${item.pontos > 0 ? "+" : ""}${item.pontos}</span>
        <span class="log-item-label">${item.label}</span>
        <button class="log-undo" data-index="${i}">desfazer</button>
      </li>
    `;
  }).join("");

  logList.querySelectorAll(".log-undo").forEach((btn) => {
    btn.addEventListener("click", () => undoLog(Number(btn.dataset.index)));
  });
}

/* ---------- Ações gerais ---------- */

function resetTurma(turma) {
  const ok = confirm(`Zerar todos os coins da turma "${turma.nome} · ${turma.horario}"? Essa ação não pode ser desfeita.`);
  if (!ok) return;
  turma.alunos.forEach((nome) => {
    const key = studentKey(turma.id, nome);
    state.students[key] = { log: [] };
  });
  saveState();
  render();
}

function resetAllData() {
  const ok = confirm("Zerar os coins e as chamadas de TODAS as turmas? Essa ação não pode ser desfeita.");
  if (!ok) return;
  state = { students: {}, attendance: {} };
  saveState();
  render();
}

function exportCSV(turma) {
  const header = "Aluno,Total de coins\n";
  const rows = turma.alunos
    .map((nome) => `"${nome.replace(/"/g, '""')}",${getStudentTotal(turma.id, nome)}`)
    .join("\n");
  const csv = header + rows;
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `innova-coins-${turma.id}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------- Utilidades ---------- */

function formatNumber(n) {
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

function escapeAttr(str) {
  return str.replace(/"/g, "&quot;");
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function slug(str) {
  return str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-");
}

let toastTimer = null;
function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.innerHTML = COIN_ICON + `<span>${msg}</span>`;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

/* ---------- Inicialização ---------- */

document.getElementById("drawer-close").addEventListener("click", closeDrawer);
document.getElementById("drawer-overlay").addEventListener("click", (e) => {
  if (e.target.id === "drawer-overlay") closeDrawer();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeDrawer();
});
document.getElementById("reset-all-btn").addEventListener("click", resetAllData);
document.querySelector(".nav-overview").addEventListener("click", () => selectTurma("overview"));

render();
